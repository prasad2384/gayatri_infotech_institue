
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="container-fluid">
        <div class="card w-100">
            <div class="card-body p-4">

                <?php if(Session::has('message')): ?>
                <script>
                    toast('success', '<?php echo e(session("message")); ?>');
                </script>
                <?php endif; ?>
                <!-- <a href="../../category/create" class="btn btn-warning btn-sm float-end">Add Category</a> -->
                <h5 class="card-title fw-semibold mb-4">Contact Table</h5>
                <div class="col-lg-12 align-items-stretch">
                    <div class="table-responsive">
                        <table class="table table-bordered text-nowrap mb-0 align-middle">
                                        <thead class="text-dark fs-4">
                                            <tr>
                                                <th class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-0">Id</h6>
                                                </th>
                                                <th class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-0">Name</h6>
                                                </th>
                                                <th class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-0">Email</h6>
                                                </th>
                                                <th class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-0">Number</h6>
                                                </th>
                                                  <th class="border-bottom-0">
                                                    <h6 class="fw-semibold mb-0">Message</h6>
                                                </th>
                                            </th>
                                            <th class="border-bottom-0">
                                              <h6 class="fw-semibold mb-0">Delete</h6>
                                          </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="border-bottom-   0">
                                                        <h6 class="fw-semibold mb-0"><?php echo e($c->id); ?></h6>
                                                    </td>
                                                    <td class="border-bottom-0">
                                                        <h6 class="fw-semibold mb-1"><?php echo e($c->name); ?></h6>
                                                    </td>
                                                    <td class="border-bottom-0">
                                                        <h6 class="fw-semibold mb-1"><?php echo e($c->email); ?></h6>
                                                    </td>
                                                    <td class="border-bottom-0">
                                                        <h6 class="fw-semibold mb-1"><?php echo e($c->number); ?></h6>
                                                    </td>
                                                    <td class="border-bottom-0">
                                                        <h6 class="fw-semibold mb-1"><?php echo e($c->message); ?></h6>
                                                    </td>
                                                    <td class="border-bottom-0">
                                                            <form action="/deletecontact/<?php echo e($c->id); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <button class="btn btn-danger btn-sm" style="background-color:red;">Delete</button>
                                                            </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\livegayatriinfotech\resources\views/admin/showcontact.blade.php ENDPATH**/ ?>