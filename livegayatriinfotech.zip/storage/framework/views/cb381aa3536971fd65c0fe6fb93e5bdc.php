
<?php $__env->startSection('content'); ?>
<?php
$page_name="Add Batch";
?>
<div class="container-fluid">
  <div class="container-fluid">
    <div class="card">
      <div class="card-body">
        <a href="../../batch" class="btn btn-sm btn-warning float-end">Show Batches</a>
        <h5 class="card-title fw-semibold mb-4"><?php echo e($page_name); ?></h5>
        <?php if(Session::has('message')): ?>
        <script>
          toast('success', '<?php echo e(session("message")); ?>');
        </script>
        <?php endif; ?>
        <div class="card">
          <div class="card-body">
            <form action="<?php echo e(route('batch.store')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label class="form-label">Select Course</label>
                <select class="form-select" name='course_id' aria-label="Default select example">
                  <option value="">--------Select Course-------</option>
                  <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($co->id); ?>"><?php echo e($co->course_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="" style="color:red"><?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <div class="mb-3">
                <label class="form-label">Batch Time</label>
                <!-- <select class="form-select" name='batch_time' aria-label="Default select example">
                            <option value="">--------Select Batch Time-------</option>
                            <option value="7AM to 8AM">7AM to 8AM</option>
                            <option value="8AM to 9AM">8AM to 9AM</option>
                            <option value="9AM to 10AM">9AM to 10AM</option>
                            <option value="10AM to 11AM">10AM to 11AM</option>
                            <option value="5PM to 6PM">5PM to 6PM</option>
                            <option value="6PM to 7PM">6PM to 7PM</option>
                            <option value="7PM to 8PM">7PM to 8PM</option>
                            <option value="8PM to 9PM">8PM to 9PM</option>
                            <option value="10AM to 9PM">10AM to 6PM</option>
                          </select> -->
                <input type="time" class="form-control" name="batch_time" name="" id="">
                <small class="" style="color:red"><?php $__errorArgs = ['batch_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <button type="submit" class="btn btn-warning"><?php echo e($page_name); ?></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/admin/batch_add.blade.php ENDPATH**/ ?>