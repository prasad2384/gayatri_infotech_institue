
<?php $__env->startSection('content'); ?>
<?php
$page_name="Update Batch"
?>
<div class="container-fluid">
        <div class="container-fluid">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4"><?php echo e($page_name); ?></h5>
              <div class="card">
                <div class="card-body">
                  <form action="<?php echo e(route('batch.update',$batch->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="mb-3">
                        <label class="form-label">Select Course</label>
                        <select class="form-select" name='course_id' aria-label="Default select example">
                            <option value="" >--------Select Course-------</option>
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($co->id); ?>"<?php echo e($co->id==$batch->course_id?'selected':''); ?>><?php echo e($co->course_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="" style="color:red"><?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Batch Time</label>
                      <div>
                        <?php echo e($batch->batch_time); ?>

                      </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Batch Time</label>
                        <!-- <select class="form-select" name='batch_time' aria-label="Default select example">
                            <option value="">--------Select Batch Time-------</option>
                            <option value="7AM to 8AM" <?php echo e($batch->batch_time=="7AM to 8AM"?'selected':''); ?>>7AM to 8AM</option>
                            <option value="8AM to 9AM" <?php echo e($batch->batch_time=='8AM to 9AM'?'selected':''); ?>>8AM to 9AM</option>
                            <option value="9AM to 10AM" <?php echo e($batch->batch_time=='9AM to 10AM'?'selected':''); ?>>9AM to 10AM</option>
                            <option value="10AM to 11AM" <?php echo e($batch->batch_time=='10AM to 11AM'?'selected':''); ?>>10AM to 11AM</option>
                            <option value="5PM to 6PM" <?php echo e($batch->batch_time=='5PM to 6PM'?'selected':''); ?>>5PM to 6PM</option>
                            <option value="6PM to 7PM" <?php echo e($batch->batch_time=='6PM to 7PM'?'selected':''); ?>>6PM to 7PM</option>
                            <option value="7PM to 8PM" <?php echo e($batch->batch_time=='7PM to 8PM'?'selected':''); ?>>7PM to 8PM</option>
                            <option value="8PM to 9PM" <?php echo e($batch->batch_time=='7PM to 8PM'?'selected':''); ?>>8PM to 9PM</option>
                            <option value="10AM to 9PM" <?php echo e($batch->batch_time=='10AM to 9PM'?'selected':''); ?>>10AM to 6PM</option>
                        </select> -->
                        <input type="time" value="<?php echo e($batch->batch_time); ?>" class="form-control" name="batch_time" name="" id="">

                      <small class="" style="color:red"><?php $__errorArgs = ['batch_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>
                    <button type="submit" class="btn btn-warning"><?php echo e($page_name); ?></button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/admin/batch_edit.blade.php ENDPATH**/ ?>