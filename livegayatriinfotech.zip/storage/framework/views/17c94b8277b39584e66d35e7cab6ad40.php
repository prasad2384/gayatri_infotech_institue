
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <div class="container-fluid">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">Add Category</h5>
              <div class="card">
                <div class="card-body">
                  <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Cateogry Name</label>
                      <input type="text" name="category_name" placeholder="Enter the Category Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Upload Image</label>
                      <input type="file" name="category_image" class="form-control" id="exampleInputPassword1">
                    </div>
                    <!-- <div class="mb-3 form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1"> -->
                      <!-- <label class="form-check-label" for="exampleCheck1">Check me out</label> -->
                    <!-- </div> -->
                    <button type="submit" class="btn btn-warning">Submit</button>
                  </form>
                </div>
              </div>
              <!-- <h5 class="card-title fw-semibold mb-4">Disabled forms</h5>
              <div class="card mb-0">
                <div class="card-body">
                  <form>
                    <fieldset disabled>
                      <legend>Disabled fieldset example</legend>
                      <div class="mb-3">
                        <label for="disabledTextInput" class="form-label">Disabled input</label>
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Disabled input">
                      </div>
                      <div class="mb-3">
                        <label for="disabledSelect" class="form-label">Disabled select menu</label>
                        <select id="disabledSelect" class="form-select">
                          <option>Disabled select</option>
                        </select>
                      </div>
                      <div class="mb-3">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="disabledFieldsetCheck" disabled>
                          <label class="form-check-label" for="disabledFieldsetCheck">
                            Can't check this
                          </label>
                        </div>
                      </div>
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </fieldset>
                  </form>
                </div>
              </div> -->
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-12 d-flex align-items-stretch">
            <div class="card w-100">
              <div class="card-body p-4">
                <h5 class="card-title fw-semibold mb-4">Category Table</h5>
                <div class="table-responsive">
                  <table class="table table-bordered text-nowrap mb-0 align-middle">
                    <thead class="text-dark fs-4">
                      <tr class="text-center">
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Id</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Category_Name</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Category_Image</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Actions</h6>
                        </th>
                        
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="border-bottom-0"><h6 class="fw-semibold mb-0"><?php echo e($dt->id); ?></h6></td>
                        <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-1"><?php echo e($dt->category_name); ?></h6>
                        </td>
                        <td class="border-bottom-0">
                            <!-- <h6 class="fw-semibold mb-1">{$dt->category_name}</h6> -->
                            <img src="../assets/images/<?php echo e($dt->category_image); ?>" height="100px" alt="">
                        </td>
                        <td class="border-bottom-0">
                        <form action="<?php echo e(route('category.destroy',$dt->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('Delete'); ?>
                            <button type="submit" class="btn btn-sm btn-danger " style="background-color: red; border:none;outline:none;">Delete</button>
                          </form>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-success  mx-2" style="background-color: green; border:none;outline:none;"><a href="<?php echo e(route('category.edit',$dt->id)); ?>">Update</a></button>
                        </td>
                      </tr> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gaytri\resources\views/admin/category.blade.php ENDPATH**/ ?>