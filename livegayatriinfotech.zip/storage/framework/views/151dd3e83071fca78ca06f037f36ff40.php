<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gayatri Infotech</title>
    <link rel="shortcut icon" type="image/png" href="../assets/images/logos/favicon.png" />
    <link rel="stylesheet" href="../assets/css/styles.min.css" />
</head>

<body>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed">
        <div class="position-relative overflow-hidden radial-gradient min-vh-100 d-flex align-items-center justify-content-center">
            <div class="d-flex align-items-center justify-content-center w-100">
                <div class="row justify-content-center w-100">
                    <div class="col-md-8 col-lg-4 col-xxl-3">
                        <div class="card mb-0">
                            <div class="card-body">
                                <a class="text-nowrap logo-img text-center d-block py-3 w-100" href="../" style="font-size:35px;color:#FFAE1F;font-weight:bolder;">
                                    &nbsp; Gayatri Infotech
                                </a>
                                <!-- <p class="text-center">Gayatri Infotech</p> -->
                                <form action="/studentlogin" method="post" class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-2">
                                        <label for="">Email ID</label>
                                        <input type="text" class="form-control mb-3" id="loginName" name="std_email" placeholder="Email_ID" value=<?php echo e(old('std_email')); ?>>
                                        <small class="" style="color:red"><?php $__errorArgs = ['std_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                                    </div>
                                    <div class="mb-2">
                                        <label for="">Password</label>
                                        <input type="password" class="form-control mb-3" id="loginPassword" name="std_password" placeholder="Password" value=<?php echo e(old('std_password')); ?>>
                                        <small class="" style="color:red"><?php $__errorArgs = ['std_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                                    </div>
                                    <div class="">
                                        <button type="submit" class="btn btn-sm btn-warning text-center w-100 py-8 fs-4 mb-4 rounded-2">LOGIN</button>
                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/student/student_login.blade.php ENDPATH**/ ?>