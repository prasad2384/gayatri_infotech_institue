
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="container-fluid">
    <div class="card w-100">
      <div class="card-body p-4">
        <?php if(Session::has('message')): ?>
        <script>
          toast('success', '<?php echo e(session("message")); ?>');
        </script>
        <?php endif; ?>
        <!-- <a href="../../course/create" class="btn btn-warning btn-sm float-end">Add Courses</a> -->
        <h5 class="card-title fw-semibold mb-4">Course Request Table</h5>
        <div class="col-lg-12 align-items-stretch">
          <div class="table-responsive">

            <form action="" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label class="form-label">Select Student</label>
                <select class="form-select" name='course_id' id="studid" aria-label="Default select example">
                  <option value="">--------Select Student-------</option>
                  <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($s->id); ?>"><?php echo e($s->std_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="" style="color:red"><?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <table class="table table-bordered text-nowrap mb-0 align-middle" id="fields">
                <thead>
                  <tr class="text-black">
                    <td>Sr.No</td>
                    <td>Course Name</td>
                    <td>Course Fees</td>
                    <td>Status</td>
                  </tr>
                </thead>
                <tbody id="studdata">

                </tbody>
              </table>
              <button type="submit" class="btn btn-warning"></button>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){
    $('#fields').hide();
$(document).on('change','#selectstudent',function(){
    var id=$(this).val();
    // alert(id);
    var markup="";
    $.ajax({
        type:'GET',
        url:'applycoursefetch/'+id,
        success:function(res){
            console.table(res);
            var count=1;
            for(i=0;i<res.length;i++)
            {
                markup+="<tr class='text-black'><td>"+count+"</td><td>"+res[i].course_name+"</td><td>"+res[i].total_fees+"</td><td>"+res[i].status+"</td></tr>";
                count++;
            }
            $('#studdata').html(markup);
            $('#fields').show();
        }
    })
})
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/admin/show_student.blade.php ENDPATH**/ ?>