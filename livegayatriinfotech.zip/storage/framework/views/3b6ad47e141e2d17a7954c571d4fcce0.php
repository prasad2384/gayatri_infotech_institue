
<?php $__env->startSection('matter'); ?>
            <div class="d-flex align-items-center justify-content-center w-100" style="margin-top: 5%;margin-bottom: 5%;">
                <div class="row justify-content-center w-100">
                    <div class="col-md-8 col-lg-4 col-xxl-3">
                        <div class="card mb-0">
                            <div class="card-body">
                                <div class="text-center">
                                    <img src="<?php echo e(asset('assets/images/logos/gayatri.png')); ?>" class="text-center" width="70%" height="120px" alt="" />
                                </div>
                                <!-- <p class="text-center">Gayatri Infotech</p> -->
                                <form action="/student_login" method="post" class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-2">
                                        <label for="">Email ID</label>
                                        <input type="text" class="form-control mb-3" id="loginName" name="std_email" placeholder="Email_ID" value=<?php echo e(old('std_email')); ?>>
                                        <small class="" style="color:red"><?php $__errorArgs = ['std_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                                    </div>
                                    <div class="mb-2">
                                        <label for="">Password</label>
                                        <input type="password" class="form-control mb-3" id="loginPassword" name="std_password" placeholder="Password" value=<?php echo e(old('std_password')); ?>>
                                        <small class="" style="color:red"><?php $__errorArgs = ['std_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                                    </div>
                                    <div class="">
                                        <button type="submit" class="btn btn-sm btn-warning text-center w-100 py-8 fs-4 mb-4 rounded-2">LOGIN</button>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\livegayatriinfotech\resources\views/student/student_login.blade.php ENDPATH**/ ?>