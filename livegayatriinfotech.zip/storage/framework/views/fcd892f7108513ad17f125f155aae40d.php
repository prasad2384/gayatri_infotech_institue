
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <div class="container-fluid">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">Add Category</h5>
              <div class="card">
                <div class="card-body">
                  <form action="<?php echo e(route('category.update',$fetch->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('Patch'); ?>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Cateogry Name</label>
                      <input type="text" name="category_name" value="<?php echo e($fetch->category_name); ?>" placeholder="Enter the Category Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      <small class="" style="color:red"><?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Uploaded Image</label>
                        <div>
                            <img src="../../assets/images/<?php echo e($fetch->category_image); ?>" class="mx-3" height="150px" alt="logo">
                        </div>
                      <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Upload Image</label>
                      <input type="file" name="category_image" class="form-control" id="exampleInputPassword1">
                    </div>
                    <!-- <div class="mb-3 form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1"> -->
                      <!-- <label class="form-check-label" for="exampleCheck1">Check me out</label> -->
                    <!-- </div> -->
                    <button type="submit" class="btn btn-info">Update</button>
                  </form>
                </div>
              </div>
             
            </div>
          </div>
        </div>
      </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/admin/category_edit.blade.php ENDPATH**/ ?>