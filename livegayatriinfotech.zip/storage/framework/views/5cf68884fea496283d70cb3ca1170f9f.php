
<?php $__env->startSection('content'); ?>
<?php
$page_name="Update Student Course";
?>
<div class="container-fluid">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <a href="../../category" class="btn btn-warning btn-sm float-end">Show Category</a>
                <h5 class="card-title fw-semibold mb-4"><?php echo e($page_name); ?></h5>
                <?php if(Session::has('message')): ?>
                <script>
                    toast('success', '<?php echo e(session("message")); ?>');
                </script>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('course_request.update',$data->course_adds_id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Student Name</label>
                                <input type="text" value="<?php echo e($data->std_name); ?>" readonly name="category_name" placeholder="Enter the Category Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                <!-- <small class="" style="color:red"><?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> -->
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Student Apply Course </label>
                                <input type="text" value="<?php echo e($data->course_name); ?>" readonly name="category_name" placeholder="Enter the Category Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                <!-- <small class="" style="color:red"><?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small> -->
                            </div>
                            <div class="mb-3 col-md-3 row">
                                <label for="exampleInputEmail1" class="form-label">Course Mode</label>
                                <div class="form-check  col">
                                    <input class="form-check-input ml-5" type="radio"  value="active" name="status" id="flexRadioDefault1" <?php echo e($data->status=="active"?'checked':''); ?>>
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        active
                                    </label>
                                </div>
                                <div class="form-check col">
                                    <input class="form-check-input" type="radio" value="inactive" name="status" id="flexRadioDefault1" <?php echo e($data->status=="inactive"?'checked':''); ?>>
                                    <label class="form-check-label" for="flexRadioDefault1">
                                        inactive
                                    </label>
                                </div>
                            </div>
                                <!-- <div class="mb-3 form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1"> -->
                                <!-- <label class="form-check-label" for="exampleCheck1">Check me out</label> -->
                                <!-- </div> -->
                                <button type="submit" id="submit-btn" class="btn btn-warning">Update</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/admin/show_student_edit.blade.php ENDPATH**/ ?>