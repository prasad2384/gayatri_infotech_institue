
<?php $__env->startSection('content'); ?>
<?php
$page_name="Add Category";
?>
<div class="container-fluid">
  <div class="container-fluid">
    <div class="card w-100">
      <div class="card-body p-4">

        <?php if(Session::has('message')): ?>
        <script>
          toast('success', '<?php echo e(session("message")); ?>');
        </script>
        <?php endif; ?>
        <a href="../../category/create" class="btn btn-warning btn-sm float-end">Add Category</a>
        <h5 class="card-title fw-semibold mb-4">Category Table</h5>
        <div class="col-lg-12 align-items-stretch">
          <div class="table-responsive">
            <table class="table table-bordered text-nowrap mb-0 align-middle">
              <thead class="text-dark fs-4">
                <tr class="text-center">
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Id</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Category_Name</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Category_Image</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Delete</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Update</h6>
                  </th>

                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="border-bottom-0">
                    <h6 class="fw-semibold mb-0"><?php echo e($dt->id); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <h6 class="fw-semibold mb-1"><?php echo e($dt->category_name); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <!-- <h6 class="fw-semibold mb-1">{$dt->category_name}</h6> -->
                    <img src="../assets/images/<?php echo e($dt->category_image); ?>" height="100px" alt="">
                  </td>
                  <td class="border-bottom-0">
                    <form action="<?php echo e(route('category.destroy',$dt->id)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('Delete'); ?>
                      <button type="submit" class="btn btn-sm btn-danger " style="background-color: red; border:none;outline:none;">Delete</button>
                    </form>
                  </td>
                  <td>
                    <a href="<?php echo e(route('category.edit',$dt->id)); ?>" class="btn btn-sm btn-warning">Update</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- kjkjkljj -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\livegayatriinfotech\resources\views/admin/category.blade.php ENDPATH**/ ?>