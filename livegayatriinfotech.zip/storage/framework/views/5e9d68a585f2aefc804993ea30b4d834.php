
<?php $__env->startSection('content'); ?>
<?php
$page_name="Add Course";
?>
<div class="container-fluid">
  <div class="container-fluid">
    <div class="card">
      <div class="card-body">
        <?php if(Session::has('message')): ?>
        <script>
          toast('success', '<?php echo e(session("message")); ?>');
        </script>
        <?php endif; ?>
        <a href="../course" class="btn btn-warning btn-sm float-end">Show Courses</a>
        <h5 class="card-title fw-semibold mb-4"><?php echo e($page_name); ?></h5>
        <div class="card">
          <div class="card-body">
            <form action="<?php echo e(route('course.store')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label class="form-label">Select Category</label>
                <select class="form-select" name='category_id' aria-label="Default select example">
                  <option value="">--------Select Category-------</option>
                  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="" style="color:red"><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Course Name</label>
                <input type="text" name="course_name" placeholder="Enter the Course Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                <small class="" style="color:red"><?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <div class="mb-3 col-md-3 row">
                <label for="exampleInputEmail1" class="form-label">Course Mode</label>
                <div class="form-check  col">
                  <input class="form-check-input ml-5" type="radio" value="Online" name="course_mode" id="flexRadioDefault1">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Online
                  </label>
                </div>
                <div class="form-check col">
                  <input class="form-check-input" type="radio" value="Offline" name="course_mode" id="flexRadioDefault1">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Offline
                  </label>
                </div>
                <small class="" style="color:red"><?php $__errorArgs = ['course_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <div class="mb-3">
                <label class="form-label">Course Fee</label>

                <input type="number" placeholder='Enter Course Fee' name="total_fee" class="form-control" name="total_fee" id="">
                <small class="" style="color:red"><?php $__errorArgs = ['total_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <div class="mb-3">
                <label class="form-label">Select Course Duration</label>
                <select class="form-select" name='course_duration' aria-label="Default select example">
                  <option value="">--------Select Course Duration-------</option>
                  <option value="3 Months">3 Months</option>
                  <option value="4 Months">4 Months</option>
                  <option value="5 Months">5 Months</option>
                  <option value="6 Months">6 Months</option>
                  <option value="7 Months">7 Months</option>
                  <option value="1 Year">1 Year</option>
                </select>
                <small class="" style="color:red"><?php $__errorArgs = ['course_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>


              <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Upload Image</label>
                <input type="file" name="course_image" class="form-control" id="exampleInputPassword1">
                <small class="" style="color:red"><?php $__errorArgs = ['course_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <!-- <div class="mb-3 form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1"> -->
              <!-- <label class="form-check-label" for="exampleCheck1">Check me out</label> -->
              <!-- </div> -->
              <div class="mb-3 col-md-3 row">
                <label for="exampleInputEmail1" class="form-label">Course Status</label>
                <div class="form-check  col">
                  <input class="form-check-input ml-5" type="radio" value="Active" name="course_status" id="flexRadioDefault1">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Active
                  </label>
                </div>
                <div class="form-check col">
                  <input class="form-check-input" type="radio" value="Inactive" name="course_status" id="flexRadioDefault1">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Inactive
                  </label>
                </div>
                <small class="" style="color:red"><?php $__errorArgs = ['course_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Short Description</label>
                <textarea name="shortdesc" placeholder="Enter the Short Description" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"></textarea>
                <small class="" style="color:red"><?php $__errorArgs = ['shortdesc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>
              <div class="mb-3" id="summernote">
                <label for="summernote_content">Long Description</label>
                <textarea class="form-control" id="summernote_content" name="summernote_content"></textarea>
                <small class="" style="color:red"><?php $__errorArgs = ['summernote_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
              </div>

              <button type="submit" class="btn btn-warning"><?php echo e($page_name); ?></button>
            </form>
            <script>
              $(document).ready(function() {
                $('#summernote_content').summernote();
              });
            </script>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\livegayatriinfotech\resources\views/admin/course_add.blade.php ENDPATH**/ ?>