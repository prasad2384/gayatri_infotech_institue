
<?php
$count=1;
?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="container-fluid">
    <div class="card w-100">
      <div class="card-body p-4">
        <?php if(Session::has('message')): ?>
        <script>
          toast('success', '<?php echo e(session("message")); ?>');
        </script>
        <?php endif; ?>
        <h5 class="card-title fw-semibold mb-4">Enrolled Course Table</h5>
        <div class="col-lg-12 d-flex align-items-stretch">
          <div class="table-responsive">
            <table class="table table-bordered text-nowrap mb-0 align-middle">
              <thead class="text-dark fs-4">
                <tr class="text-center">
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Sr No</h6>
                  </th>
                  <!-- <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Category Name</h6>
                  </th> -->
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Course Name</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Duration</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Total Fee</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Status</h6>
                  </th>
                  <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Batch Time</h6>
                  </th>
                  <!-- <th class="border-bottom-0">
                    <h6 class="fw-semibold mb-0">Delete</h6>
                  </th> -->
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $applied_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="border-bottom-0 text-center">
                    <h6 class="fw-semibold mb-0"><?php echo e($count); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <h6 class="fw-semibold mb-1"><?php echo e($dt->course_name); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <h6 class="fw-semibold mb-1"><?php echo e($dt->course_duration); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <h6 class="fw-semibold mb-1"><?php echo e($dt->total_fees); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <h6 class="fw-semibold mb-1"><?php echo e($dt->status); ?></h6>
                  </td>
                  <td class="border-bottom-0">
                    <?php if($dt->batch_time!=0): ?>
                    <h6 class="fw-semibold mb-1"><?php echo e($dt->batch_time); ?></h6>
                    <?php else: ?>
                    <h6 class="fw-semibold mb-1">No Batch Time is Available</h6>
                  </td>
                  <?php endif; ?>
                  <?php
                  $count++;
                  ?>
                  <!-- <td class="border-bottom-0">
                    <form action="/appliedcoursedelete/<?php echo e($dt->id); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('Delete'); ?>
                      <button type="submit" class="btn btn-sm btn-danger " style="background-color: red; border:none;outline:none;">Delete</button>
                    </form>
                  </td> -->
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gayatriinfotech/gayatri/resources/views/student/appliedcourses.blade.php ENDPATH**/ ?>