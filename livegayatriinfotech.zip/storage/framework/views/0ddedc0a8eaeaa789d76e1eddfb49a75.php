<?php
use App\Models\course;
$course_all=course::all();
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
  <meta charset="utf-8">
  <title>Gayatri Infotech</title>

  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <!-- ** Plugins Needed for the Project ** -->
  <!-- Bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/bootstrap/bootstrap.min.css')); ?>">
  <!-- slick slider -->
  <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/slick/slick.css')); ?>">
  <!-- themefy-icon -->
  <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/themify-icons/themify-icons.css')); ?>">
  <!-- animation css -->
  <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/animate/animate.css')); ?>">
  <!-- aos -->
  <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/aos/aos.css')); ?>">
  <!-- venobox popup -->
  <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/venobox/venobox.css')); ?>">

  <!-- Main Stylesheet -->
  <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">

  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">
  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logos/favicon.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.min.css')); ?>" />
     <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logos/favicon.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.min.css')); ?>" />
</head>
<body>
  
  <!-- Modal -->
  <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content rounded-0 border-0 p-4">
        <div class="modal-header border-0">
          <h3>Login</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         
        </div>
      </div>
    </div>
  </div>

  <!-- header -->
  <header class="fixed-top header">
    <!-- top header -->
    <div class="top-header py-2 bg-white">
      <div class="container">
        <div class="row no-gutters">
          <!--<div class="col-lg-4 text-center text-lg-left">-->
          <!--  <a class="text-color mr-3" href="/"><strong>CALL</strong> 9422781840</a>-->
          <!--  <ul class="list-inline d-inline">-->
          <!--    <li class="list-inline-item mx-0"><a class="d-inline-block p-2 text-color" href="/"><i class="ti-facebook"></i></a></li>-->
          <!--    <li class="list-inline-item mx-0"><a class="d-inline-block p-2 text-color" href="/"><i class="ti-twitter-alt"></i></a></li>-->
          <!--    <li class="list-inline-item mx-0"><a class="d-inline-block p-2 text-color" href="/"><i class="ti-linkedin"></i></a></li>-->
          <!--    <li class="list-inline-item mx-0"><a class="d-inline-block p-2 text-color" href="/"><i class="ti-instagram"></i></a></li>-->
          <!--  </ul>-->
          <!--</div>-->
          <!--<div class="col-lg-8 text-center text-lg-right">-->
          <!--  <ul class="list-inline">-->
              <!-- <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="notice.html">notice</a></li> -->
              <!-- <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="research.html">research</a></li> -->
              <!-- <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="scholarship.html">SCHOLARSHIP</a></li> -->
          <!--    <?php if(session('std_email')==''): ?>-->
          <!--    <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="../student_login_page">login</a></li>-->
          <!--    <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="../student_register_page" >register</a></li>-->
          <!--    <?php else: ?>-->
          <!--    <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="/studentlogouts">logout</a></li>-->
          <!--    <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="../studentdashboard"> User Dashboard</a></li>-->
          <!--    <li class="list-inline-item"><a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block"><?php echo e(session('std_email')); ?></a></li>-->
          <!--    <?php endif; ?>-->
          <!--  </ul>-->
          <!--</div>-->
        </div>
      </div>
    </div>
    <!-- navbar -->
    <div class="navigation w-100" style="background-color: white;">
      <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light p-0">
          <a class="navbar-brand" style="font-weight: bold;font-size:21px;color:orange" href="/"><img height="80px" src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="logo">&nbsp;Gayatri Infotech</a>
          <button class="navbar-toggler rounded-0" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ml-auto text-center">
              <li class="nav-item active">
                <a class="nav-link" href="/">Home</a>
              </li>
              <li class="nav-item @about">
                <a class="nav-link" href="../about">About</a>
              </li>
              <li class="nav-item @courses">
                <a class="nav-link" href="/courses">COURSES</a>
              </li>

              <li class="nav-item @contact">
                <a class="nav-link" href="../contact">CONTACT</a>
              </li>
              <?php if(session('std_email')==''): ?>
              <li class="nav-item @contact">
                <a class="nav-link" href="../student_login_page">Login</a>
                </li>
                <li class="nav-item @contact">
                <a class="nav-link" href="../student_register_page">Register</a>
              </li>
               <?php else: ?>
              <li class="nav-item @contact">
                <a class="nav-link" href="/studentlogouts">Logout</a>
              </li>
              <li class="nav-item @contact">
                <a class="nav-link" href="../studentdashboard">User Dashboard</a>
              </li>
              <li class="nav-item @contact">
                <a class="nav-link" href=""><?php echo e(session('std_email')); ?></a>
              </li>
              <?php endif; ?>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  </header>
  <?php echo $__env->yieldContent('matter'); ?>
  <!-- footer -->
  <footer>
    <!-- newsletter -->
    <!-- <div class="newsletter">
    <div class="container">
      <div class="row">
        <div class="col-md-9 ml-auto bg-primary py-5 newsletter-block">
          <h3 class="text-white">Subscribe Now</h3>
          <form action="#">
            <div class="input-wrapper">
              <input type="email" class="form-control border-0" id="newsletter" name="newsletter" placeholder="Enter Your Email...">
              <button type="submit" value="send" class="btn btn-primary">Join</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    </div> -->
    <!-- footer content -->
    <div class="footer bg-footer section border-bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-8 mb-5 mb-lg-0">
            <!-- logo -->
            <a class="logo-footer" href="/" style="font-weight:bold;font-size:30px;color:orange"><img class="mb-3" src="<?php echo e(asset('frontend/images/logo.png')); ?>" height="50px" alt="logo">&nbsp;Gayatri Infotech</a>
            <p class="text-white">Firmament morning sixth subdue darkness creeping gathered divide our let god moving. Moving in fourth air night bring upon it beast let you dominion likeness open place day great.</p>
          </div>
          <!-- company -->
          <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-5 mb-md-0">
            <h4 class=" mb-3" style="font-weight:bold;color:orange">Courses</h4>
            <ul class="list-unstyled">
              <?php $__currentLoopData = $course_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="mb-1"><a class="text-white" href="/single_page/<?php echo e($co->id); ?>"><?php echo e($co->course_name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <!-- links -->
          <!-- <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-5 mb-md-0">
                <h4 class="text-white mb-5">LINKS</h4>
                <ul class="list-unstyled">
                  <li class="mb-3"><a class="text-color" href="courses.html">Courses</a></li>
                  <li class="mb-3"><a class="text-color" href="event.html">Events</a></li>
                  <li class="mb-3"><a class="text-color" href="gallary.html">Gallary</a></li>
                  <li class="mb-3"><a class="text-color" href="faqs.html">FAQs</a></li>
                </ul>
              </div> -->
          <!-- support -->
          <div class="col-lg-2 col-md-5 col-sm-4 col-6 mb-3 mb-md-0">
            <h4 class=" mb-3" style="font-weight:bold;color:orange">Address</h4>
            <ul class="list-unstyled">
              <li class="mb-3 text-white"><a class="text-white" href="#">9/4, Shri Markendaya Yantramag Dharak Society, Near New WIT College, Next to Upahar Bakery lane, Solapur - 413006.</a></li>
              <li class="mb-3 text-white"><a class="text-white" href="#"> +91 9422781840</a></li>
              <li class="mb-1 text-white"><a class="text-white" href="#"> gayatriinfotech123@gmail.com</a></li>
            </ul>
          </div>
          <!-- support -->

        </div>
      </div>
    </div>
    <!-- copyright -->
    <!-- <div class="copyright py-4 bg-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-7 text-sm-left text-center">
          <p class="mb-0">Copyright
            <script>
              var CurrentYear = new Date().getFullYear()
              document.write(CurrentYear)
            </script> 
            © Theme By <a href="https://themefisher.com">themefisher.com</a></p> . All Rights Reserved.
        </div>
        <div class="col-sm-5 text-sm-right text-center">
          <ul class="list-inline">
            <li class="list-inline-item"><a class="d-inline-block p-2" href="https://www.facebook.com/themefisher"><i class="ti-facebook text-primary"></i></a></li>
            <li class="list-inline-item"><a class="d-inline-block p-2" href="https://www.twitter.com/themefisher"><i class="ti-twitter-alt text-primary"></i></a></li>
            <li class="list-inline-item"><a class="d-inline-block p-2" href="#"><i class="ti-instagram text-primary"></i></a></li>
            <li class="list-inline-item"><a class="d-inline-block p-2" href="https://dribbble.com/themefisher"><i class="ti-dribbble text-primary"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    </div> -->
  </footer>
  <!-- /footer -->

  <!-- jQuery -->
  <script src="<?php echo e(asset('frontend/plugins/jQuery/jquery.min.js')); ?>"></script>
  <!-- Bootstrap JS -->
  <script src="<?php echo e(asset('frontend/plugins/bootstrap/bootstrap.min.js')); ?>"></script>
  <!-- slick slider -->
  <script src="<?php echo e(asset('frontend/plugins/slick/slick.min.js')); ?>"></script>
  <!-- aos -->
  <script src="<?php echo e(asset('frontend/plugins/aos/aos.js')); ?>"></script>
  <!-- venobox popup -->
  <script src="<?php echo e(asset('frontend/plugins/venobox/venobox.min.js')); ?>"></script>
  <!-- mixitup filter -->
  <script src="<?php echo e(asset('frontend/plugins/mixitup/mixitup.min.js')); ?>"></script>
  <!-- google map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
  <script src="<?php echo e(asset('frontend/plugins/google-map/gmap.js')); ?>"></script>

  <!-- Main Script -->
  <script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script>
  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>



  <!-- <script>
    $(document).ready(function() {

      $('#btnstore').on('click', function() {
        var std_name = $('#std_name').val();
        var std_email = $('#std_email').val();
        var std_password = $('#std_password').val();
        var std_phoneno = $('#std_phoneno').val();
        var std_dob = $('#std_dob').val();
        var std_gender = $('#std_gender').val();
        var std_profile = $('#std_profile')[0].files[0];
        var std_clgname = $('#std_clgname').val();
        var std_degree = $('#std_degree').val();
        var std_clgtimefrom = $('#std_clgtimefrom').val();
        var std_clgtimeto = $('#std_clgtimeto').val();
        var std_passoutyear = $('#std_passoutyear').val();
        var std_university = $('#std_university').val();
        var std_parentsname = $('#std_parentsname').val();
        var std_parentsno = $('#std_parentsno').val();
        var std_parentsoccupation = $('#std_parentsoccupation').val();
        var std_address = $('#std_address').val();
        // alert($std_name);
        // console("hi");
        var formData = new FormData();
        formData.append('_token', '<?php echo e(csrf_token()); ?>');
        formData.append('std_name', std_name);
        formData.append('std_email', std_email);
        formData.append('std_password', std_password);
        formData.append('std_phoneno', std_phoneno);
        formData.append('std_dob', std_dob);
        formData.append('std_gender', std_gender);
        formData.append('std_profile', std_profile);
        formData.append('std_clgname', std_clgname);
        formData.append('std_degree', std_degree);
        formData.append('std_clgtimefrom', std_clgtimefrom);
        formData.append('std_clgtimeto', std_clgtimeto);
        formData.append('std_passoutyear', std_university);
        formData.append('std_university', std_university);
        formData.append('std_parentsname', std_parentsname);
        formData.append('std_parentsno', std_parentsno);
        formData.append('std_parentsoccupation', std_parentsno);
        formData.append('std_address', std_parentsno);

        // var data = {
        //   std_name: std_name,
        //   std_email: std_email,
        //   std_password: std_password,
        //   std_phoneno: std_phoneno,
        //   std_dob: std_dob,
        //   std_gender: std_gender,
        //   std_profile: std_profile,
        //   std_clgname: std_clgname,
        //   std_degree: std_degree,
        //   std_clgtimefrom: std_clgtimefrom,
        //   std_clgtimeto: std_clgtimeto,
        //   std_passoutyear: std_passoutyear,
        //   std_university: std_university,
        //   std_parentsname: std_parentsname,
        //   std_parentsno: std_parentsno,
        //   std_parentsoccupation: std_parentsoccupation,
        //   std_address: std_address,
        // }
        console.log(formData);
        $.ajax({
          type: "POST",
          // method:'PUT',
          url: "/api/studentstore",
          data: formData,
          contentType: false,
          processData: false,
          success: function(res) {
            console.log(res);
          },
          error: function(data) {
            var errors=data.responseJSON.errors;
            console.log(errors);
            if(errors.hasOwnProperty('std_address')){
              document.getElementById('add_error').innerHTML=errors.std_address[0];
            }
            else
            {
              document.getElementById('add_error').innerHTML='';
            }
            if(errors.hasOwnProperty('std_clgname')){
              document.getElementById('parents_occupation_error').innerHTML=errors.std_clgname[0];
            }
          }
        })
      })
    });
  </script> -->
   <script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\livegayatriinfotech\resources\views/student/header.blade.php ENDPATH**/ ?>