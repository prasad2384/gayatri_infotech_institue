<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Congratulations 🎉 <?php echo e($student_name); ?></p>
    <p>Your <?php echo e($batch_name); ?> Course is now Active and Your Batch Time is <?php echo e($batch_time); ?></p>
    <p>Thank You...</p>
</body>
</html><?php /**PATH G:\wamp64\www\laravel\gayatri\resources\views/admin/active_batch_email.blade.php ENDPATH**/ ?>