
<?php $__env->startSection('content'); ?>
<?php
$page_name="Add Fees";
?>
<div class="container-fluid">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <!-- <a href="../../batch" class="btn btn-sm btn-warning float-end">Show Fees</a> -->
                <h5 class="card-title fw-semibold mb-4"><?php echo e($page_name); ?></h5>
                <?php if(Session::has('message')): ?>
                <script>
                    toast('success', '<?php echo e(session("message")); ?>');
                </script>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <form action="" method="post" id="s_id" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label">Select Student</label>
                                <select class="form-select" id="selectstudent" name='student_id' aria-label="Default select example">
                                    <option value="">--------Select Student-------</option>
                                    <?php $__currentLoopData = $student_fetch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st->id); ?>"><?php echo e($st->std_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span id="totalcourse">No courses Applied</span>
                                <small class="" style="color:red"><?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                            </div>
                            <div class="mb-3">
                                <ul id="stud_courses"></ul>
                            </div>
                            <!-- <div class="mb-3 fields">
                                <label class="form-label">Total Fee</label>

                                <h6></h6>
                                <input type="number" class="form-control " name="course_fee" id="">
                                <small class="" style="color:red"><?php $__errorArgs = ['batch_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                            </div> -->
                            <div class="mb-3 fields">
                                <label class="form-label">Pay Fee</label>
                                <input type="number" class="form-control" name="paid_fees" id="input_fee">
                                <small class="" style="color:red"><?php $__errorArgs = ['batch_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                                <span id='greater_than_remaining' style="color:red;">Not More Than Remaining Fee</span>
                            </div>
                            <button type="submit" id="btn" class="btn btn-warning"><?php echo e($page_name); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('.fields').hide();
        $('#totalcourse').hide();
        $('#greater_than_remaining').hide();
        $('#btn').hide();
        $(document).on('change', '#selectstudent', function() {
            $("#stud_courses").html("");
            var id = $(this).val();
            // $('.fields').show();
            $.ajax({
                type: 'GET',
                url: 'fetchcourse/' + id,
                success: function(res) {
                    // alert(res);
                    console.log(res);
                    if (res == '') {
                        alert('Course Not Entrolled');
                        $('#btn').hide();
                        $('.fields').hide();
                    } else {
                        $('#btn').show();
                        $('#s_id').attr('action', '/addfee/' + id);
                        let total_fees = 0;
                        // alert(res.length);
                        for (var i = 0; i < res.length; i++) {
                            $("#stud_courses").append(
                                "<li class='text-black'>" + res[i].course_name + " - " + res[i].total_fees + "</li>"
                            );
                            total_fees += parseInt(res[i].total_fees);
                        }
                        $.ajax({
                            type: "GET",
                            url: 'showfee/' + id,
                            success: function(result) {
                                let remaining_fees = parseInt(total_fees - result.paid_fees);
                                // alert(remaining_fees);
                                $("#stud_courses").append("<li class='mb-2 '> Paid Fees : " + parseInt(result.paid_fees) + "</li>");
                                $("#stud_courses").append("<li class='mb-2 ' style='background-color:red;color:white'> Remaining Fees : " + remaining_fees + "</li>");

                                $(document).on('keyup', '#input_fee', function() {
                                    var input_fees = $(this).val();
                                    console.log(input_fees);
                                    console.log(remaining_fees);
                                    if (remaining_fees < input_fees) {
                                        $('#greater_than_remaining').show();
                                        $('#btn').hide();
                                        // alert('Your Enter Fees is greater than Remaining Fees');
                                    } else {
                                        $('#greater_than_remaining').hide();

                                        $('#btn').show();
                                    }
                                });
                                // if (total_fees == result.paid_fees) {
                                //     alert('All payment is done')
                                //     // $('#btn').hide();
                                //     // $('.fields').hide();
                                // }
                                // else
                                // {
                                //     // $('.fields').show();
                                // // $('#btn').show();
                                // }

                            }
                        });
                        $("#stud_courses").append("<li class='text-info'>Total Fees : " + total_fees + "</li>");
                        $('.fields').show();
                    }
                }
            })
            // alert(id);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\laravel\livegayatriinfotech\resources\views/admin/add_fees.blade.php ENDPATH**/ ?>