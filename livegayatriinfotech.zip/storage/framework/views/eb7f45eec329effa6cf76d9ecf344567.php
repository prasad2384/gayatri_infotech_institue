
<?php $__env->startSection('matter'); ?>
<?php
use App\Models\course;
$course=course::all();
?>
<!-- Modal -->


<!-- hero slider -->
<section class="hero-section overlay bg-cover" data-background="<?php echo e(asset('frontend/images/banner/banner-1.jpg')); ?>">
  <div class="container">
    <div class="hero-slider">
      <!-- slider item -->
      <div class="hero-slider-item">
        <div class="row">
          <div class="col-md-8">
            <h1 class="text-white" data-animation-out="fadeOutRight" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInLeft" data-delay-in=".1">Your bright future is our mission</h1>
            <p class="text-muted mb-4" data-animation-out="fadeOutRight" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInLeft" data-delay-in=".4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor
              incididunt ut labore et
              dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exer</p>
            <a href="/contact" class="btn btn-primary" data-animation-out="fadeOutRight" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInLeft" data-delay-in=".7">Apply now</a>
          </div>
        </div>
      </div>
      <!-- slider item -->
      <div class="hero-slider-item">
        <div class="row">
          <div class="col-md-8">
            <h1 class="text-white" data-animation-out="fadeOutUp" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInDown" data-delay-in=".1">Your bright future is our mission</h1>
            <p class="text-muted mb-4" data-animation-out="fadeOutUp" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInDown" data-delay-in=".4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor
              incididunt ut labore et
              dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exer</p>
            <a href="contact.html" class="btn btn-primary" data-animation-out="fadeOutUp" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInDown" data-delay-in=".7">Apply now</a>
          </div>
        </div>
      </div>
      <!-- slider item -->
      <div class="hero-slider-item">
        <div class="row">
          <div class="col-md-8">
            <h1 class="text-white" data-animation-out="fadeOutDown" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInUp" data-delay-in=".1">Your bright future is our mission</h1>
            <p class="text-muted mb-4" data-animation-out="fadeOutDown" data-delay-out="5" data-duration-in=".3" data-animation-in="fadeInUp" data-delay-in=".4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor
              incididunt ut labore et
              dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exer</p>
            <a href="contact.html" class="btn btn-primary" data-animation-out="fadeOutDown" data-delay-out="5" data-duration-in=".3" data-animation-in="zoomIn" data-delay-in=".7">Apply now</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- about us -->
<section class="section">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-6 order-2 order-md-1">
        <h2 class="section-title">About Educenter</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat </p>
        <p>cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>
        <a href="about" class="btn btn-primary">Learn more</a>
      </div>
      <div class="col-md-6 order-1 order-md-2 mb-4 mb-md-0">
        <img class="img-fluid w-100" src="frontend/images/about/about-us.jpg" alt="about image">
      </div>
    </div>
  </div>
</section>

    <!-- about us -->
    <section class="section">
      <div class="container">
      <div class="row">
      <div class="col-12">
        <div class="d-flex align-items-center section-title justify-content-between">
          <h2 class="mb-0 text-nowrap mr-3">Our Course</h2>
          <div class="border-top w-100 border-primary d-none d-sm-block"></div>
          <div>
            <a href="courses" class="btn btn-sm btn-primary-outline ml-sm-3 d-none d-sm-block">see all</a>
          </div>
        </div>
      </div>
    </div>
        <div class="row justify-content-center">
          <!-- course item -->
          <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4 col-sm-6 mb-5">
            <div class="card p-0 border-primary rounded-0 hover-shadow">
              <a href="/single_page/<?php echo e($co->id); ?>">
                <img class="card-img-top rounded-0" src="../../assets/images/<?php echo e($co->course_image); ?>" height="200px" alt="course thumb">
              </a>
              <div class="card-body">
                <ul class="list-inline mb-2">
                  <!-- <li class="list-inline-item"><i class="ti-calendar mr-1 text-color"></i>02-14-2018</li> -->
                  <li class="list-inline-item"><a class="text-color" href="#"><?php echo e($co->total_fees); ?> ₹</a></li>
                </ul>
                <a href="/single_page/<?php echo e($co->id); ?>">
                  <h4 class="card-title"><?php echo e($co->course_name); ?></h4>
                </a>
                <!-- <p class="card-text mb-4"><?php echo e($co->shortdesc); ?></p> -->
                <!-- <?php echo e($co->longdesc); ?> -->
                <form action="/studentcourseadd/<?php echo e($co->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-primary btn-sm">Add Course</button>
                </form>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- course item -->
        </div>
        <!-- /course list -->
    </section>
    <!-- /about us -->

    <!-- courses -->
    <!--  -->
    <!-- /courses -->

    <!-- cta -->

    <!-- /cta -->

    <!-- success story -->

    <!-- /success story -->

    <!-- events -->

    <!-- /events -->

    <!-- teachers -->

    <!-- /teachers -->

    <!-- blog -->

    <!-- /blog -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('student.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gayatriinfotech/gayatri/resources/views/student/index.blade.php ENDPATH**/ ?>