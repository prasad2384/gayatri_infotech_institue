
<?php $__env->startSection('content'); ?>
<?php
$page_name="Add Faculty";
?>
<div class="container-fluid">
        <div class="container-fluid">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4"><?php echo e($page_name); ?></h5>
              <div class="card">
                <div class="card-body">
                  <form action="<?php echo e(route('faculty.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Select Course</label>
                        <select class="form-select" name='course_id' aria-label="Default select example">
                            <option value="" >--------Select Course-------</option>
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($co->id); ?>"><?php echo e($co->course_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Faculty Name</label>
                      <input type="text" name="faculty_name" placeholder="Enter the Faculty Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Phone No</label>
                      <input type="text" name="faculty_mobileno" maxlength="10" placeholder="8855******" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">City</label>
                      <input type="text" name="faculty_city" placeholder="City Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                      <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                    </div>
                    <!-- <div class="mb-3 col-md-3 row">
                      <label for="exampleInputEmail1" class="form-label">Course Mode</label>
                        <div class="form-check  col">
                            <input class="form-check-input ml-5" type="radio" value="Online" name="course_mode" id="flexRadioDefault1">
                            <label class="form-check-label" for="flexRadioDefault1">
                                Online
                            </label>
                        </div>
                        <div class="form-check col">
                            <input class="form-check-input" type="radio" value="Offline" name="course_mode" id="flexRadioDefault1">
                                <label class="form-check-label" for="flexRadioDefault1">
                                     Offline
                                </label>
                        </div>
                    </div> -->
                    <!-- <div class="mb-3">
                        <label class="form-label">Course Fee</label>
                        <select class="form-select" name='total_fee' aria-label="Default select example">
                            <option value="">--------Select Course Fee-------</option>
                            <option value="3000">3000</option>
                            <option value="4000">4000</option>
                            <option value="5000">5000</option>
                            <option value="8000">8000</option>
                            <option value="10000">10000</option>
                            <option value="20000">20000</option>
                        </select>
                    </div> -->
                    <!-- <div class="mb-3">
                        <label class="form-label">Select Course Duration</label>
                        <select class="form-select" name='course_duration' aria-label="Default select example">
                            <option value="">--------Select Course Duration-------</option>
                            <option value="3 Months">3 Months</option>
                            <option value="4 Months">4 Months</option>
                            <option value="5 Months">5 Months</option>
                            <option value="6 Months">6 Months</option>
                            <option value="7 Months">7 Months</option>
                            <option value="1 Year">1 Year</option>
                        </select>
                    </div> -->
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Upload Image</label>
                      <input type="file" name="faculty_image" class="form-control" id="exampleInputPassword1">
                    </div>
                    <!-- <div class="mb-3 form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1"> -->
                      <!-- <label class="form-check-label" for="exampleCheck1">Check me out</label> -->
                    <!-- </div> -->
                    <!-- <div class="mb-3 col-md-3 row">
                      <label for="exampleInputEmail1" class="form-label">Course Status</label>
                        <div class="form-check  col">
                            <input class="form-check-input ml-5" type="radio"  value="Active" name="course_status" id="flexRadioDefault1">
                            <label class="form-check-label" for="flexRadioDefault1">
                                Active
                            </label>
                        </div>
                        <div class="form-check col">
                            <input class="form-check-input" type="radio" value="Inactive" name="course_status" id="flexRadioDefault1">
                                <label class="form-check-label" for="flexRadioDefault1">
                                     Inactive
                                </label>
                        </div>
                    </div> -->
                    <button type="submit" class="btn btn-warning"><?php echo e($page_name); ?></button>
                  </form>
                </div>
              </div>
              <!-- <h5 class="card-title fw-semibold mb-4">Disabled forms</h5>
              <div class="card mb-0">
                <div class="card-body">
                  <form>
                    <fieldset disabled>
                      <legend>Disabled fieldset example</legend>
                      <div class="mb-3">
                        <label for="disabledTextInput" class="form-label">Disabled input</label>
                        <input type="text" id="disabledTextInput" class="form-control" placeholder="Disabled input">
                      </div>
                      <div class="mb-3">
                        <label for="disabledSelect" class="form-label">Disabled select menu</label>
                        <select id="disabledSelect" class="form-select">
                          <option>Disabled select</option>
                        </select>
                      </div>
                      <div class="mb-3">
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" id="disabledFieldsetCheck" disabled>
                          <label class="form-check-label" for="disabledFieldsetCheck">
                            Can't check this
                          </label>
                        </div>
                      </div>
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </fieldset>
                  </form>
                </div>
              </div> -->
            </div>
          </div>
        </div>
      </div>
      <!-- table start -->
      <div class="col-lg-12 d-flex align-items-stretch">
            <div class="card w-100">
              <div class="card-body p-4">
                <h5 class="card-title fw-semibold mb-4">Course Table</h5>
                <div class="table-responsive">
                     <table class="table table-bordered text-nowrap mb-0 align-middle">
                    <thead class="text-dark fs-4">
                      <tr class="text-center">
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Sr.No</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Course Name</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Faculty Name</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Phone No</h6>
                        </th>                       
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">Image</h6>
                        </th>
                        <th class="border-bottom-0" colspan="2">
                          <h6 class="fw-semibold mb-0">Actions</h6>
                        </th>
                        
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $course_faculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="border-bottom-0 text-center"><h6 class="fw-semibold mb-0"><?php echo e($dt->id); ?></h6></td>
                        
                        <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-1"><?php echo e($dt->course_name); ?></h6>
                        </td>
                        <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-1"><?php echo e($dt->faculty_name); ?></h6>
                        </td>
                        <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-1"><?php echo e($dt->faculty_mobileno); ?></h6>
                        </td>
                        
                        <td class="border-bottom-0">
                            <img src="../assets/images/<?php echo e($dt->faculty_image); ?>" height="100px" alt="">
                        </td> 
                        <!-- <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-1"><?php echo e($dt->course_status); ?></h6>
                        </td> -->
                        <td class="border-bottom-0">
                        <form action="<?php echo e(route('faculty.destroy',$dt->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('Delete'); ?>
                            <button type="submit" class="btn btn-sm btn-danger " style="background-color: red; border:none;outline:none;">Delete</button>
                          </form>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-warning  mx-2" style="  border:none;outline:none;"><a href="<?php echo e(route('faculty.edit',$dt->id)); ?>" class="text-white">Update</a></button>
                        </td>
                      </tr> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\gaytri\resources\views/admin/faculty.blade.php ENDPATH**/ ?>